export type ICSSStyleDeclarationEntry = readonly [value: string, priority: string];
