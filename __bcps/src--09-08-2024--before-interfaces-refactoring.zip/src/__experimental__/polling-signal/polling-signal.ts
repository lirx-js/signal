import { createIdle } from '@lirx/utils';
import { signalAsReadonly } from '../../internal/reactive-context.protected.js';
import { SIGNAL } from '../../signal/signal.symbol.js';
import { IReadonlySignal } from '../../signal/types/readonly-signal.type.js';
import { ISignalUpdateFunctionCallback } from '../../signal/types/signal-update-function-callback.type.js';
import { ISignal } from '../../signal/types/signal.type.js';
import {
  initPollingSignalNode,
  IPollingSignalNode,
  POLLING_SIGNAL_NODE,
  pollingSignalGet,
  pollingSignalSet,
  pollingSignalThrow,
  pollingSignalUpdate,
} from './internal/polling-signal.protected.js';
import { ICreatePoolingSignalOptions } from './types/create-pooling-signal-options.type.js';
import { IPollingSignal } from './types/polling-signal.type.js';

export function pollingSignal<GValue>({
  equal,
  read,
  write,
  schedule = createIdle,
}: ICreatePoolingSignalOptions<GValue>): IPollingSignal<GValue> {
  const node: IPollingSignalNode<GValue> = Object.create(POLLING_SIGNAL_NODE);
  initPollingSignalNode<GValue>(node, equal, read, write, schedule);

  const pollingSignal: IPollingSignal<GValue> = ((): GValue =>
    pollingSignalGet<GValue>(node)) as ISignal<GValue>;
  pollingSignal[SIGNAL] = node;

  pollingSignal.set = (value: GValue): void => pollingSignalSet<GValue>(node, value);
  pollingSignal.throw = (error: unknown): void => pollingSignalThrow<GValue>(node, error);
  pollingSignal.update = (updateFunction: ISignalUpdateFunctionCallback<GValue>): void =>
    pollingSignalUpdate<GValue>(node, updateFunction);
  pollingSignal.asReadonly = (): IReadonlySignal<GValue> => signalAsReadonly<GValue>(node);

  return pollingSignal;
}
