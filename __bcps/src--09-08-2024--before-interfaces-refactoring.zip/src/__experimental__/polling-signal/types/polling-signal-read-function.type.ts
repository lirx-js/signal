export interface IPollingSignalReadFunction<GValue> {
  (): GValue;
}
