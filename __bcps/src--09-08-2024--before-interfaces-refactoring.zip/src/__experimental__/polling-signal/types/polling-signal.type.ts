import { ISignal } from '../../../signal/types/signal.type.js';

export interface IPollingSignal<GValue> extends ISignal<GValue> {}
