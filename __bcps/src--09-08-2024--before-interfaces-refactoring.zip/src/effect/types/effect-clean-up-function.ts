export interface IEffectCleanUpFunction {
  (): void;
}
