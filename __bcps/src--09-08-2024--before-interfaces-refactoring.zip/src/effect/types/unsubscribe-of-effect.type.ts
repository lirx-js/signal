export interface IUnsubscribeOfEffect {
  (): void;
}
