import { IEffectCleanUpFunction } from './effect-clean-up-function.js';

export interface IEffetFunction {
  (): IEffectCleanUpFunction | void;
}
