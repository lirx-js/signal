import { ICreateSignalOptions } from '../../signal/types/create-signal-options.type.js';

export interface ICreateComputedOptions<GValue> extends ICreateSignalOptions<GValue> {}
