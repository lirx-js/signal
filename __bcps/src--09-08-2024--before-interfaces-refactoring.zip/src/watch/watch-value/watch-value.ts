import { SignalError } from '../../internal/signal-error.class.js';
import { IReadonlySignal } from '../../signal/types/readonly-signal.type.js';
import { IUnsubscribeOfWatch } from '../types/unsubscribe-of-watch.type.js';
import { IWatchCleanUpFunction } from '../types/watch-clean-up-function.type.js';
import { watch } from '../watch.js';
import { IWatchErrorFunction } from './types/watch-error-function.type.js';
import { WATCH_ERROR_THROW } from './types/watch-error-throw.constant.js';
import { IWatchValueFunction } from './types/watch-value-function.type.js';

export function watchValue<GValue>(
  signal: IReadonlySignal<GValue>,
  watchValueFunction: IWatchValueFunction<GValue>,
  watchErrorFunction: IWatchErrorFunction = WATCH_ERROR_THROW,
): IUnsubscribeOfWatch {
  return watch(signal, (value: GValue | SignalError): IWatchCleanUpFunction | void => {
    return value instanceof SignalError
      ? watchErrorFunction(value.error)
      : watchValueFunction(value);
  });
}
