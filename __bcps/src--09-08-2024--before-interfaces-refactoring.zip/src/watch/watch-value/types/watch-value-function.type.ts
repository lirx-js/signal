import { IWatchCleanUpFunction } from '../../types/watch-clean-up-function.type.js';

export interface IWatchValueFunction<GValue> {
  (value: GValue): IWatchCleanUpFunction | void;
}
