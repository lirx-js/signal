import { IWatchErrorFunction } from './watch-error-function.type.js';

export const WATCH_ERROR_THROW: IWatchErrorFunction = (error: unknown): void => {
  throw error;
};
