import { IWatchCleanUpFunction } from '../../types/watch-clean-up-function.type.js';

export interface IWatchErrorFunction {
  (error: unknown): IWatchCleanUpFunction | void;
}
