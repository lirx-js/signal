export interface IWatchCleanUpFunction {
  (): void;
}
