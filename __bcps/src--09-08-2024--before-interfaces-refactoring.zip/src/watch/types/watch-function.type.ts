import { SignalError } from '../../internal/signal-error.class.js';
import { IWatchCleanUpFunction } from './watch-clean-up-function.type.js';

export interface IWatchFunction<GValue> {
  (value: GValue | SignalError): IWatchCleanUpFunction | void;
}
