export interface IUnsubscribeOfWatch {
  (): void;
}
