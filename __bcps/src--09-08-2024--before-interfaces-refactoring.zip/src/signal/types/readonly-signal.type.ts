import { SIGNAL } from '../signal.symbol.js';

export interface IReadonlySignal<GValue> {
  (): GValue;

  [SIGNAL]: unknown;
}
