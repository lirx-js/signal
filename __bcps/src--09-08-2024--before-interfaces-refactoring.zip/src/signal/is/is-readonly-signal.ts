import { isFunction } from '@lirx/utils';
import { SIGNAL } from '../signal.symbol.js';
import { IReadonlySignal } from '../types/readonly-signal.type.js';

export function isReadonlySignal<GValue>(input: unknown): input is IReadonlySignal<GValue> {
  return isFunction(input) && SIGNAL in input;
}
