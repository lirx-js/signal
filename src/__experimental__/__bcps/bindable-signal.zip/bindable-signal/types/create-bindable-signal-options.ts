import { CreateSignalOptions } from '../../../signal/types/create-signal-options.js';

export interface CreateBindableSignalOptions<GValue> extends CreateSignalOptions<GValue> {}
