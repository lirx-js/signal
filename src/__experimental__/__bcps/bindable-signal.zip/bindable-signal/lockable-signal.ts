import { createIdle } from '@lirx/utils';
import { signalAsReadonly } from '../../internal/reactive-context.protected.js';
import { SIGNAL } from '../../signal/signal.symbol.js';
import { ReadonlySignal } from '../../signal/types/readonly-signal.js';
import { SignalUpdateFunctionCallback } from '../../signal/types/signal-update-function-callback.js';
import { Signal } from '../../signal/types/signal.js';
import {
  BINDABLE_SIGNAL_NODE,
  bindableSignalGet,
  BindableSignalNode,
  bindableSignalSet,
  bindableSignalThrow,
  bindableSignalUpdate,
  initBindableSignalNode,
} from './internal/locked-signal.protected.js';
import { BindableSignal } from './types/bindable-signal.js';
import {
  CreateBindableSignalOptions,
  CreateLockedSignalOptions,
} from './types/create-bindable-signal-options.js';

export function bindableSignal<GValue>({
  equal,
  read,
  write,
  schedule = createIdle,
}: CreateBindableSignalOptions<GValue>): BindableSignal<GValue> {
  const node: BindableSignalNode<GValue> = Object.create(BINDABLE_SIGNAL_NODE);
  initBindableSignalNode<GValue>(node, equal, read, write, schedule);

  const bindableSignal: BindableSignal<GValue> = ((): GValue =>
    bindableSignalGet<GValue>(node)) as Signal<GValue>;
  bindableSignal[SIGNAL] = node;

  bindableSignal.set = (value: GValue): void => bindableSignalSet<GValue>(node, value);
  bindableSignal.throw = (error: unknown): void => bindableSignalThrow<GValue>(node, error);
  bindableSignal.update = (updateFunction: SignalUpdateFunctionCallback<GValue>): void =>
    bindableSignalUpdate<GValue>(node, updateFunction);
  bindableSignal.asReadonly = (): ReadonlySignal<GValue> =>
    signalAsReadonly<GValue>(node, bindableSignal);

  return bindableSignal;
}
