import { EqualFunction, UndoFunction } from '@lirx/utils';
import {
  initSignalNode,
  isInWatcherContext,
  notifySignalNodeWatchers,
  readSignalNode,
  runInWatcherContext,
  SIGNAL_NODE_WITH_READONLY,
  signalGet,
  SignalNodeWithReadonly,
  watchSignalNode,
  writeSignalNode,
} from '../../../internal/reactive-context.protected.js';
import { SignalError } from '../../../internal/signal-error.js';
import { SignalUpdateFunctionCallback } from '../../../signal/types/signal-update-function-callback.js';

/* TYPES */

export interface BindableSignalNode<GValue> extends SignalNodeWithReadonly<GValue> {
  read: IBindableSignalReadFunction<GValue>;
  write: IBindableSignalWriteFunction<GValue>;
  schedule: IBindableSignalScheduleFunction;
  unsubscribe: UndoFunction | undefined;
}

/* INIT */

export const POLLING_SIGNAL_NODE: BindableSignalNode<unknown> = {
  ...SIGNAL_NODE_WITH_READONLY,
  read: undefined as any,
  write: undefined as any,
  schedule: undefined as any,
  unsubscribe: undefined as any,
  update: updateBindableSignal as any,
};

export function initBindableSignalNode<GValue>(
  pollingSignalNode: BindableSignalNode<GValue>,
  equal: EqualFunction<GValue> | undefined,
  read: IBindableSignalReadFunction<GValue>,
  write: IBindableSignalWriteFunction<GValue>,
  schedule: IBindableSignalScheduleFunction,
): void {
  initSignalNode<GValue>(pollingSignalNode, runInWatcherContext<GValue>(undefined, read), equal);
  pollingSignalNode.read = read;
  pollingSignalNode.write = write;
  pollingSignalNode.schedule = schedule;
}

/* FUNCTIONS */

export function readBindableSignal<GValue>(pollingSignalNode: BindableSignalNode<GValue>): boolean {
  const currentValue: GValue | SignalError = pollingSignalNode.value;
  let newValue: GValue | SignalError;
  try {
    newValue = runInWatcherContext<GValue>(undefined, pollingSignalNode.read);
  } catch (error: unknown) {
    newValue = new SignalError(error);
  }

  if (writeSignalNode<GValue>(pollingSignalNode, newValue)) {
    notifySignalNodeWatchers<GValue>(pollingSignalNode, currentValue);
    return true;
  } else {
    return false;
  }
}

export function watchBindableSignalUntilChangedOrUnobserved<GValue>(
  pollingSignalNode: BindableSignalNode<GValue>,
): void {
  if (pollingSignalNode.unsubscribe === undefined) {
    pollingSignalNode.unsubscribe = pollingSignalNode.schedule((): void => {
      pollingSignalNode.unsubscribe = undefined;
      if (pollingSignalNode.watchers.length > 0 && !readBindableSignal<GValue>(pollingSignalNode)) {
        watchBindableSignalUntilChangedOrUnobserved(pollingSignalNode);
      }
    });
  }
}

export function updateBindableSignal<GValue>(pollingSignalNode: BindableSignalNode<GValue>): void {
  readBindableSignal<GValue>(pollingSignalNode);
  watchBindableSignalUntilChangedOrUnobserved<GValue>(pollingSignalNode);
}

export function clearBindableSignalScheduledUpdate<GValue>(
  pollingSignalNode: BindableSignalNode<GValue>,
): void {
  if (pollingSignalNode.unsubscribe !== undefined) {
    pollingSignalNode.unsubscribe();
    pollingSignalNode.unsubscribe = undefined;
  }
}

/* METHODS */

// GET

export function pollingSignalGet<GValue>(pollingSignalNode: BindableSignalNode<GValue>): GValue {
  readBindableSignal<GValue>(pollingSignalNode);
  if (isInWatcherContext()) {
    watchBindableSignalUntilChangedOrUnobserved<GValue>(pollingSignalNode);
  }
  watchSignalNode<GValue>(pollingSignalNode);
  return readSignalNode<GValue>(pollingSignalNode);
}

// SET

export function pollingSignalSet<GValue>(
  pollingSignalNode: BindableSignalNode<GValue>,
  value: GValue | SignalError,
): void {
  if (value instanceof SignalError) {
    throw new Error('Cannot throw this signal.');
  } else {
    if (pollingSignalNode.write(value) !== false) {
      clearBindableSignalScheduledUpdate<GValue>(pollingSignalNode);
      readBindableSignal<GValue>(pollingSignalNode);
    }
  }
}

export function pollingSignalThrow<GValue>(
  pollingSignalNode: BindableSignalNode<GValue>,
  error: unknown,
): void {
  pollingSignalSet<GValue>(pollingSignalNode, new SignalError(error));
}

export function pollingSignalUpdate<GValue>(
  pollingSignalNode: BindableSignalNode<GValue>,
  updateFunction: SignalUpdateFunctionCallback<GValue>,
): void {
  const currentValue: GValue = signalGet<GValue>(pollingSignalNode);
  let value: GValue | SignalError;

  try {
    value = updateFunction(currentValue);
  } catch (error: unknown) {
    value = new SignalError(error);
  }

  pollingSignalSet<GValue>(pollingSignalNode, value);
}
