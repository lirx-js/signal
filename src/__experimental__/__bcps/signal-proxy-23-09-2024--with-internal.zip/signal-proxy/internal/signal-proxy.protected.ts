import { EqualFunction, UndoFunction } from '@lirx/utils';
import {
  ComputedNode,
  initSignalNode,
  isInWatcherContext,
  notifySignalNodeWatchers,
  readSignalNode,
  runInWatcherContext,
  SIGNAL_NODE,
  SIGNAL_NODE_WITH_READONLY,
  signalGet,
  SignalNode,
  SignalNodeWithReadonly,
  signalSet,
  signalUpdate,
  watchSignalNode,
  writeSignalNode,
} from '../../../internal/reactive-context.protected.js';
import { SignalError } from '../../../internal/signal-error.js';
import { SIGNAL } from '../../../signal/signal.symbol.js';
import { ReadonlySignal } from '../../../signal/types/readonly-signal.js';
import { SignalUpdateFunctionCallback } from '../../../signal/types/signal-update-function-callback.js';

/* TYPES */

export interface SignalProxyNode<GValue> extends SignalNodeWithReadonly<GValue> {
  boundSignal: ReadonlySignal<GValue> | undefined;
}

/* INIT */

export const SIGNAL_PROXY_NODE: SignalProxyNode<unknown> = {
  ...SIGNAL_NODE_WITH_READONLY,
  boundSignal: undefined,
  update: updateSignalProxyNode as any,
};

export function initSignalProxyNode<GValue>(
  signalProxyNode: SignalProxyNode<GValue>,
  value: GValue | SignalError,
  equal: EqualFunction<GValue> | undefined,
): void {
  initSignalNode<GValue>(signalProxyNode, value, equal);
}

/* FUNCTIONS */

function throwBecauseSignalProxyIsReadonly(): never {
  throw new Error('SignalProxy bound to another signal, therefore it is readonly.');
}

function getSignalProxyNodeBoundNode<GValue>(
  signalProxyNode: SignalProxyNode<GValue>,
): SignalNode<GValue> {
  return signalProxyNode.boundSignal![SIGNAL] as SignalNode<GValue>;
}

function updateSignalProxyNode<GValue>(signalProxyNode: SignalProxyNode<GValue>): void {
  if (signalProxyNode.boundSignal !== undefined) {
    const signalNode: SignalNode<GValue> = getSignalProxyNodeBoundNode<GValue>(signalProxyNode);
    signalNode.update?.(signalNode);
  }
}

/* METHODS */

// GET

export function signalProxyGet<GValue>(signalProxyNode: SignalProxyNode<GValue>): GValue {
  if (signalProxyNode.boundSignal === undefined) {
    return signalGet<GValue>(signalProxyNode);
  } else {
    return signalProxyNode.boundSignal();
  }
}

// SET

export function signalProxySet<GValue>(
  signalProxyNode: SignalProxyNode<GValue>,
  value: GValue | SignalError,
): void {
  if (signalProxyNode.boundSignal === undefined) {
    signalSet<GValue>(signalProxyNode, value);
  } else {
    throwBecauseSignalProxyIsReadonly();
  }
}

export function signalProxyThrow<GValue>(
  signalProxyNode: SignalProxyNode<GValue>,
  error: unknown,
): void {
  if (signalProxyNode.boundSignal === undefined) {
    signalProxySet<GValue>(signalProxyNode, new SignalError(error));
  } else {
    throwBecauseSignalProxyIsReadonly();
  }
}

export function signalProxyUpdate<GValue>(
  signalProxyNode: SignalProxyNode<GValue>,
  updateFunction: SignalUpdateFunctionCallback<GValue>,
): void {
  if (signalProxyNode.boundSignal === undefined) {
    signalUpdate<GValue>(signalProxyNode, updateFunction);
  } else {
    throwBecauseSignalProxyIsReadonly();
  }
}

/* BIND */

export function signalProxyIsBound<GValue>(signalProxyNode: SignalProxyNode<GValue>): boolean {
  return signalProxyNode.boundSignal !== undefined;
}

export function signalProxyBind<GValue>(
  signalProxyNode: SignalProxyNode<GValue>,
  signal: ReadonlySignal<GValue>,
): UndoFunction {
  if (signalProxyNode.boundSignal !== undefined) {
    throw new Error('SignalProxy already bound to another signal.');
  }

  const signalNode = signal[SIGNAL] as SignalNode<GValue>;

  return (): void => {};
}
