import { CreateSignalOptions } from '../../../signal/types/create-signal-options.js';

export interface CreateSignalProxyOptions<GValue> extends CreateSignalOptions<GValue> {}
