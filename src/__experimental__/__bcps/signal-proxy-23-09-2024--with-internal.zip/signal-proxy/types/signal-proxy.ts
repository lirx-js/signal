import { UndoFunction } from '@lirx/utils';
import { ReadonlySignal } from '../../../signal/types/readonly-signal.js';
import { Signal } from '../../../signal/types/signal.js';

export interface SignalProxy<GValue> extends Signal<GValue> {
  bound(): boolean;

  bind(signal: ReadonlySignal<GValue>): UndoFunction;
}
