import { UndoFunction } from '@lirx/utils';
import { initSignalNode, signalAsReadonly } from '../../internal/reactive-context.protected.js';
import { SignalError } from '../../internal/signal-error.js';
import { SIGNAL } from '../../signal/signal.symbol.js';
import { ReadonlySignal } from '../../signal/types/readonly-signal.js';
import { SignalUpdateFunctionCallback } from '../../signal/types/signal-update-function-callback.js';
import {
  SIGNAL_PROXY_NODE,
  signalProxyBind,
  signalProxyGet,
  signalProxyIsBound,
  SignalProxyNode,
  signalProxySet,
  signalProxyThrow,
  signalProxyUpdate,
} from './internal/signal-proxy.protected.js';
import { CreateSignalProxyOptions } from './types/create-signal-proxy-options.js';
import { SignalProxyConstructor } from './types/signal-proxy-constructor.js';
import { SignalProxy } from './types/signal-proxy.js';

export const signalProxy: SignalProxyConstructor = (<GValue>(
  initialValue: GValue | SignalError,
  options?: CreateSignalProxyOptions<GValue>,
): SignalProxy<GValue> => {
  // preventCreationIfInSignalContext();

  const node: SignalProxyNode<GValue> = Object.create(SIGNAL_PROXY_NODE);
  initSignalNode<GValue>(node, initialValue, options?.equal);

  const signal: SignalProxy<GValue> = ((): GValue =>
    signalProxyGet<GValue>(node)) as SignalProxy<GValue>;
  signal[SIGNAL] = node;

  signal.set = (value: GValue): void => signalProxySet<GValue>(node, value);
  signal.throw = (error: unknown): void => signalProxyThrow<GValue>(node, error);
  signal.update = (updateFunction: SignalUpdateFunctionCallback<GValue>): void =>
    signalProxyUpdate<GValue>(node, updateFunction);
  signal.asReadonly = (): ReadonlySignal<GValue> => signalAsReadonly<GValue>(node, signal);

  signal.bound = (): boolean => signalProxyIsBound<GValue>(node);
  signal.bind = (signal: ReadonlySignal<GValue>): UndoFunction =>
    signalProxyBind<GValue>(node, signal);

  return signal;
}) as SignalProxyConstructor;

signalProxy.unset = <GValue>(options?: CreateSignalProxyOptions<GValue>): SignalProxy<GValue> => {
  return signalProxy<GValue>(SignalError.UNSET, options);
};
