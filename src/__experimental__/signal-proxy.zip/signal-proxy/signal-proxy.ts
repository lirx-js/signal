import { UndoFunction } from '@lirx/utils';
import { computed } from '../../computed/computed.js';
import { SignalError } from '../../internal/signal-error.js';
import { signal } from '../../signal/signal.js';
import { ReadonlySignal } from '../../signal/types/readonly-signal.js';
import { SignalUpdateFunctionCallback } from '../../signal/types/signal-update-function-callback.js';
import { Signal } from '../../signal/types/signal.js';
import { untracked } from '../../untracked/untracked.js';
import { runIfSignalHasMethod } from './internal/signal-proxy.protected.js';
import { CreateSignalProxyOptions } from './types/create-signal-proxy-options.js';
import { SignalProxyConstructor } from './types/signal-proxy-constructor.js';
import { SignalProxy } from './types/signal-proxy.js';

export const signalProxy: SignalProxyConstructor = (<GValue>(
  initialValue: GValue | SignalError,
  options?: CreateSignalProxyOptions<GValue>,
): SignalProxy<GValue> => {
  const defaultSignal: Signal<GValue> = signal<GValue>(initialValue, options);

  const sourceSignal: Signal<ReadonlySignal<GValue>> =
    signal<ReadonlySignal<GValue>>(defaultSignal);

  const signalProxy: SignalProxy<GValue> = computed<GValue>((): GValue => {
    const _sourceSignal: ReadonlySignal<GValue> = sourceSignal();
    const _value: GValue = _sourceSignal();
    if (_sourceSignal !== defaultSignal) {
      defaultSignal.set(_value);
    }
    return _value;
  }, options) as SignalProxy<GValue>;

  signalProxy.set = (value: GValue): void => {
    return runIfSignalHasMethod(
      untracked(sourceSignal),
      'set',
      (sourceSignal: Signal<GValue>): void => {
        sourceSignal.set(value);
      },
    );
  };

  signalProxy.throw = (error: unknown): void => {
    return runIfSignalHasMethod(
      untracked(sourceSignal),
      'throw',
      (sourceSignal: Signal<GValue>): void => {
        sourceSignal.throw(error);
      },
    );
  };

  signalProxy.update = (updateFunction: SignalUpdateFunctionCallback<GValue>): void => {
    return runIfSignalHasMethod(
      untracked(sourceSignal),
      'update',
      (sourceSignal: Signal<GValue>): void => {
        sourceSignal.update(updateFunction);
      },
    );
  };

  signalProxy.asReadonly = (): ReadonlySignal<GValue> => {
    return signalProxy; // TODO improve
  };

  signalProxy.locked = (): boolean => {
    return untracked(sourceSignal) !== defaultSignal;
  };

  signalProxy.lockWith = (signal: ReadonlySignal<GValue>): UndoFunction => {
    if (signalProxy.locked()) {
      throw new Error('SignalProxy already locked by another signal.');
    } else {
      sourceSignal.set(signal);
      let done: boolean = false;
      return (): void => {
        if (!done) {
          done = true;
          sourceSignal.set(defaultSignal);
        }
      };
    }
  };

  return signalProxy;
}) as SignalProxyConstructor;

signalProxy.unset = <GValue>(options?: CreateSignalProxyOptions<GValue>): SignalProxy<GValue> => {
  return signalProxy<GValue>(SignalError.UNSET, options);
};

signalProxy.thrown = <GValue>(
  error: unknown,
  options?: CreateSignalProxyOptions<GValue>,
): SignalProxy<GValue> => {
  return signalProxy<GValue>(new SignalError(error), options);
};
