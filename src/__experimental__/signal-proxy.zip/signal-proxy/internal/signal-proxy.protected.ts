import { ReadonlySignal } from '../../../signal/types/readonly-signal.js';

// export function signalHasMethod<GSignal extends ReadonlySignal<any>, GOutSignal extends GSignal>(
//   signal: GSignal,
//   methodName: keyof GOutSignal,
// ): signal is GOutSignal {
//   return Reflect.has(signal, methodName);
// }

export function runIfSignalHasMethod<
  GSignal extends ReadonlySignal<any>,
  GOutSignal extends GSignal,
  GReturn,
>(
  signal: GSignal,
  methodName: keyof GOutSignal,
  callback: (signal: GOutSignal) => GReturn,
): GReturn {
  if (Reflect.has(signal, methodName)) {
    return callback(signal as GOutSignal);
  } else {
    throw new Error(
      `The signal bound with this SignalProxy does not have the method ${JSON.stringify(methodName)}.`,
    );
  }
}
