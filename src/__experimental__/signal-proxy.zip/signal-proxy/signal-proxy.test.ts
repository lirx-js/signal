import { describe, expect, it } from '@jest/globals';
import { signalProxy } from './signal-proxy.js';

describe('signal-proxy', () => {
  describe('initial value', () => {
    it('should have correct initial value', () => {
      const a = signalProxy(1);
      expect(a()).toBe(1);
    });

    it('should throw if no initial value', () => {
      const a = signalProxy.unset();
      expect(() => a()).toThrow();
    });

    it('should throw if errored initial value', () => {
      const error = new Error();
      const a = signalProxy.thrown(error);
      expect(() => a()).toThrow(error);
    });
  });

  describe('set', () => {
    it('should "set" properly a new value', () => {
      const a = signalProxy(1);
      expect(a()).toBe(1);

      a.set(2);
      expect(a()).toBe(2);
    });

    it('should "throw" properly an error', () => {
      const a = signalProxy(1);
      expect(a()).toBe(1);

      const error = new Error();
      a.throw(error);
      expect(() => a()).toThrow(error);

      a.set(2);
      expect(a()).toBe(2);
    });
  });

  describe('proxy', () => {
    describe('computed', () => {
      it('should return correct value', () => {
        return new Promise<void>(
          (resolve: (value: void) => void, reject: (reason?: any) => void): void => {
            // let _a: number = 0;
            // let readCount: number = 0;
            // const a = signalProxy.unset();
            //
            // expect(readCount).toBe(1);
            // expect(a()).toBe(0);
            // expect(readCount).toBe(2);
            // a.set(1);
            // expect(_a).toBe(1);
            // expect(a()).toBe(1);
            // expect(readCount).toBe(4);
            // _a = 2;
            // expect(a()).toBe(2);
            // expect(readCount).toBe(5);
            //
            // let count: number = -1;
            // const stopWatch = watchValue(a, (a: number) => {
            //   count++;
            //
            //   if (count === 0) {
            //     expect(a).toBe(2);
            //     expect(readCount).toBe(6);
            //     _a = 3;
            //   } else if (count === 1) {
            //     expect(a).toBe(3);
            //     expect(readCount).toBe(8);
            //     _a = 4;
            //   } else if (count === 2) {
            //     expect(a).toBe(4);
            //     expect(readCount).toBe(10);
            //     _a = 5;
            //     stopWatch();
            //     setTimeout(() => {
            //       expect(readCount).toBe(11);
            //       resolve();
            //     }, 20);
            //   } else {
            //     reject();
            //   }
            // });
          },
        );
      });
    });
  });
});
