import { SignalError } from '../../../internal/signal-error.js';
import { CreateSignalProxyOptions } from './create-signal-proxy-options.js';
import { SignalProxy } from './signal-proxy.js';

export interface SignalProxyConstructor {
  <GValue>(
    initialValue: GValue | SignalError,
    options?: CreateSignalProxyOptions<GValue>,
  ): SignalProxy<GValue>;

  unset<GValue>(options?: CreateSignalProxyOptions<GValue>): SignalProxy<GValue>;

  thrown<GValue>(error: unknown, options?: CreateSignalProxyOptions<GValue>): SignalProxy<GValue>;
}
